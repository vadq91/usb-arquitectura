package nube;

import nube.service.Credentials;
import nube.service.impl.S3impl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;


public class Main {
    private static final Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        S3impl s3impl = new S3impl();

        try{
            s3impl.uploadFile(Credentials.CREDENTIALSAWS.getBucketName(), Credentials.CREDENTIALSAWS.getPathKey(), fileChooser());
        }catch (Exception e){
            log.error(e.getMessage());
        }

    }
    public static String fileChooser() {
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Texto", "txt ", "text", "pdf", "jpg", "zip");
        fileChooser.setFileFilter(filter);
        String filePath = "";

        int returnValue = fileChooser.showOpenDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {

            File selectedFile = fileChooser.getSelectedFile();

            filePath = selectedFile.getAbsolutePath();


        } else {
            System.out.println("No se seleccionó ningún archivo.");
        }
        return filePath;
    }



}

