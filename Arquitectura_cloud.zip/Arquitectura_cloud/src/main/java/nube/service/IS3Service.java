package nube.service;

public interface IS3Service {
    void uploadFile(String bucketName, String key, String filePath) throws Exception;
}
