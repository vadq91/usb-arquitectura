package nube.service.impl;

import nube.service.IS3Service;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import javax.swing.*;
import java.nio.file.Paths;

public class S3impl implements IS3Service {


    @Override
    public void uploadFile(String bucketName, String key, String filePath) throws  Exception{
        Region region = Region.US_EAST_2; // Region del contenedor AWS
        S3Client s3 = S3Client.builder()
                .region(region)
                .credentialsProvider(ProfileCredentialsProvider.create("default")) // Usar el perfil 'default' de las credeciales AWS
                .build();


        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();

        s3.putObject(putObjectRequest, RequestBody.fromFile(Paths.get(filePath)));
        JOptionPane.showMessageDialog(null, "Archivo cargado Exitosamente");

    }
}
