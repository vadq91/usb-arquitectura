package nube.service;

public enum Credentials {

    CREDENTIALSAWS("bucket-arquitectura-nube", "C:\\Users\\diego\\OneDrive\\Documentos\\especializacion\\'Arquitectura de Proyectos'\\Arquitecturas\\Arquitectura_cloud\\src\\main\\resources\\credentials");

    private final String bucketName;
    private final String pathKey;

    Credentials (String bucketName, String pathKey){
        this.bucketName = bucketName;
        this.pathKey = pathKey;
    }

    public String getBucketName() {
        return bucketName;
    }

    public String getPathKey() {
        return pathKey;
    }
}
